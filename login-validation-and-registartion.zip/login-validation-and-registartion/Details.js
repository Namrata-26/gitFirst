import React from 'react';
import {SafeAreaView, StyleSheet, View, Text, ImageBackground,Button} from 'react-native';

export default class Details extends React.Component{

        render(){
            //const { navigate, state } = this.props.navigation;
            const { navigation } = this.props;  
            const name = navigation.getParam('name','Saumya')
            const email = navigation.getParam('email', 'Not_Defined') 
           
            return(

              <ImageBackground source={{uri:'https://i.pinimg.com/1200x/45/ee/fe/45eefecc477df47593b361a04b2d4cfa.jpg' }} style={{width:null,height:null,flex:1,justifyContent:'center'}}>

               <View>
                  
                <Text style={{fontSize:30,justifyContent:'center',textAlign:'center'}}><b>Details Of USer</b> </Text>
                <Text>{"\n"}</Text>
                  <Text>{"\n"}</Text>
                    <Text>{"\n"}</Text>
                      <Text>{"\n"}</Text>

                <Text style={{fontSize:20,justifyContent:'center',textAlign:'center'}}
                >Name Of User : {JSON.stringify(name)}</Text>  

                <Text>{"\n"}</Text>

                <Text style={{fontSize:20,justifyContent:'center',textAlign:'center'}}>Email ID : {JSON.stringify(email)}</Text> 


                 


                </View>
                </ImageBackground>
               
                
            )
        }


}