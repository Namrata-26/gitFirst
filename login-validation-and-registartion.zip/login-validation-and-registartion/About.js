import React from 'react';
import { Button, StyleSheet, Text, View ,TextInput, ImageBackground} from 'react-native';



export default class About extends React.Component{

        render(){
            const { navigate, state } = this.props.navigation;
           
            return(
           
        
            <ImageBackground source={{uri:'https://i.pinimg.com/1200x/45/ee/fe/45eefecc477df47593b361a04b2d4cfa.jpg' }} style={{width:null,height:900,flex:1,justifyContent:'center'}}>

                <View>
                <Text style={{fontSize:30,justifyContent:'center',textAlign:'center'}}><b>Welcome </b></Text>
                <Text style={{fontSize:20,justifyContent:'center',textAlign:'center'}}>You Have Successfully Logged In!!!</Text>
           

                </View>


                </ImageBackground>
            )
        }


}