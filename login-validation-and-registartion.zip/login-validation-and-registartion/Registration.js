import { StatusBar } from 'expo-status-bar';
import { Formik } from 'formik';
import React from 'react';
import { Button, StyleSheet, Text, View ,TextInput, ImageBackground,TouchableHighlight} from 'react-native';
import {withFormik} from 'formik';

class Registration extends React.Component{
    state={
        name:"",
        email:"",
        password:""
      }

    static navigationOptions = {
        title: 'Register',
          headerStyle: { backgroundColor: 'aqua' },
        headerTitleStyle: { color: 'brown' },
         };
    render(){
            const { navigate, state } = this.props.navigation;
            return(
               
    
    <View>
      <ImageBackground source={{uri:'https://i.pinimg.com/1200x/45/ee/fe/45eefecc477df47593b361a04b2d4cfa.jpg' }} style={{width:null,height:900,flex:1,justifyContent:'center'}}>
        <TextInput  
        value={this.state.name}  
        onChangeText={name => this.setState({ name })}  
        placeholder={'Enter Name'} 
         
        style={{height:42,width:"80%",borderBottomWidth:1,fontWeight:'bold'}}
        />  
        <Text>{"\n"}</Text>
         <TextInput  
        value={this.state.email}  
        onChangeText={email => this.setState({ email })}  
        placeholder={'Enter Email'}  
        style={{height:42,width:"80%",borderBottomWidth:1,fontWeight:'bold'}}
        />  
        <Text>{"\n"}</Text>
        <TextInput  
        value={this.state.password} 
        secureTextEntry={true} 
        onChangeText={password => this.setState({ password })}  
        placeholder={'Enter Password'}  
        style={{height:42,width:"80%",borderBottomWidth:1,fontWeight:'bold',alignItems: 'center', }}
        />  
        <Text>{"\n"}</Text>
        <Text>{"\n"}</Text>

        <TouchableHighlight style={{padding:10,margin:20,backgroundColor:'pink',borderRadius:4,textAlign:'center'}}   
         onPress={() =>  
            this.props.navigation.navigate('Details', {  
                email: this.state.email
                
            })  
            } >
                <Text><b>Register Here</b></Text>
              </TouchableHighlight>
       
                
               
     
        </ImageBackground>
    </View>
           
         
        );

    }

}

const styles = StyleSheet.create({
    container: {
      flex: 1,
     
      alignItems: 'center',
      justifyContent: 'center',
    },
    validatetext:{
      color:'red'
    }
  });
  
  
  export default withFormik({
  mapPropsToValues: () => ({email:"",password:""}),
  validate:(values,props) => {
      const errors={};
      if(!values.email){
        errors.email='Email Required';
        
      }
  
      if(!values.password){
        errors.password='Password Required';
      }else if(values.password.length<8) {
            errors.password='Minimum length of password is 8 character';
      }
      return errors;
  },

  })(Registration);