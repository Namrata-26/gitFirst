
import React from 'react';
import { View, Text, Button } from 'react-native';
import { createAppContainer } from 'react-navigation';
import { createStackNavigator } from 'react-navigation-stack';

// Components

import Login from './Login'
//import Login from './assets/Login';
import About from './About';
import Registration from './Registration';
import Details from './Details';


const Navigator = createStackNavigator({
    Login: { screen: Login },
   
   About:{screen:About},

   Registration:{screen:Registration},

   Details:{screen:Details}
     
});



const App = createAppContainer(Navigator);

export default App;
